angular.module('app').controller('tabController',['$rootScope','$scope','utils',function($rootScope,$scope,utils){
	$scope.vo = {
    	index:0
    };
    
    $scope.vc = {
        
    };

    $scope.ready = function(){
        
    }();
}]);